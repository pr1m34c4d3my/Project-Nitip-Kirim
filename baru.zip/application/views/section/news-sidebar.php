<div class="col-md-3">
          <aside class="news-sidebar">
            <div class="categories widget">
              <h4>CATEGORIES</h4>
              <ul>
                <li><a href="#">Transportation</a></li>
                <li><a href="#">Logistic</a></li>
                <li><a href="#">Packaging</a></li>
                <li><a href="#">Ground Shipping</a></li>
                <li><a href="#">Air Shipping</a></li>
                <li><a href="#">Sea Shipping</a></li>
              </ul>
            </div>
            <!--end widget -->
            <div class="recent-posts widget">
              <h4>LATEST NEWS</h4>
              <ul>
                <li>
                  <figure><img src="images/news1.jpg" alt="Image"></figure>
                  <a href="#">Digital services used to be seen in this way</a></li>
                <li>
                  <figure><img src="images/news2.jpg" alt="Image"></figure>
                  <a href="#">As a cost to be minimized by hiring </a></li>
                <li>
                  <figure><img src="images/news3.jpg" alt="Image"></figure>
                  <a href="#">Compete with each other on price and quality</a></li>
                <li>
                  <figure><img src="images/news4.jpg" alt="Image"></figure>
                  <a href="#">Large organizations spending less on their </a></li>
              </ul>
            </div>
            <!-- end widget -->
            <div class="gallery widget">
              <h4>GALLERY</h4>
              <ul>
                <li><a href="#"><img src="images/news1.jpg" alt="Image"></a></li>
                <li><a href="#"><img src="images/news2.jpg" alt="Image"></a></li>
                <li><a href="#"><img src="images/news3.jpg" alt="Image"></a></li>
                <li><a href="#"><img src="images/news4.jpg" alt="Image"></a></li>
              </ul>
            </div>
            <!-- end widget -->
            <div class="tags widget">
              <h4>NEWS TAGS</h4>
              <ul>
                <li><a href="#">Package</a></li>
                <li><a href="#">Box</a></li>
                <li><a href="#">Deliver</a></li>
                <li><a href="#">Shipping</a></li>
                <li><a href="#">Truck</a></li>
                <li><a href="#">Sea</a></li>
                <li><a href="#">Train</a></li>
                <li><a href="#">Logistic</a></li>
                <li><a href="#">Transport</a></li>
              </ul>
            </div>
            <!-- end widget --> 
          </aside>
          <!-- end news-sidebar --> 
        </div>